#pragma once
#include<iostream>
#include "tablero.h"

void pantallaInicio(char tablero[X][Y], bool gameOver, std::vector<int>infoPartida);

