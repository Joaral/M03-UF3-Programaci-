#pragma once
#include <iostream>
#include <time.h>
#include <cstdlib>
#include <vector>
#include <string>
#include <fstream>

#define X 5
#define Y 2

void creacionTablero(char tablero[X][Y]);

void renderTablero(char tablero[X][Y]);